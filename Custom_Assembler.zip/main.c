#include "assembler.h"

int main(int argc, char *argv[]) {
    assembler(argc, argv);
    return 0;
}
